from django.apps import AppConfig


class TvosConfig(AppConfig):
    name = 'tvos'
