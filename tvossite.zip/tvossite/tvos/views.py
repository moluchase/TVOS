import json
import os

from django.http import HttpResponse
from django.shortcuts import render

# Create your views here.
from django.template.loader import get_template

from tvos.models import Record

"""
def index(request):
    template=get_template('index.html')
    record=Record.objects.all()#从数据库中查找所有的记录
    abspath=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    path=os.path.dirname(os.path.dirname(__file__))
    staticPath=os.path.join(os.path.dirname(__file__),'static').replace('\\','/')
    html=template.render(locals())
    return HttpResponse(html)
"""


#django模板会自动找到app下面的templates文件夹中的模板文件
#显示字符串
def index(request):
    template=get_template('index.html')#获取模板

    record=Record.objects.all()#获取全部记录
    
    project_dict={}
    owner_dict={}
    company_dict={}
    date_list=[]
    insert_list=[]
    delete_list=[]
    project_name=[]
    project_num=[]
    owner_name=[]
    owner_num=[]
    company_name=[]
    company_num=[]

    #读取数据
    for row in record:
        if row.project not in project_dict.keys():
            project_dict[row.project]=0
        if row.owner not in owner_dict.keys():
            owner_dict[row.owner]=0
        if row.company not in company_dict.keys():
            company_dict[row.company]=0
        project_dict[row.project]+=1
        owner_dict[row.owner]+=1
        company_dict[row.company]+=1
        date_list.append(str(row.updated))
        insert_list.append(row.insertions)
        delete_list.append(row.deletions)

    for key,value in project_dict.items():
        project_name.append(key)
        project_num.append(value)
    for key,value in owner_dict.items():
        owner_name.append(key)
        owner_num.append(value)
    for key,value in company_dict.items():
        company_name.append(key)
        company_num.append(value)

    return render(request, 'home.html',
                  {'dateList': json.dumps(date_list),
                   'insertList': json.dumps(insert_list), 'deleteList': json.dumps(delete_list),
                   'ownerName': json.dumps(owner_name), 'ownerNum': json.dumps(owner_num),
                   'companyName': json.dumps(company_name), 'companyNum': json.dumps(company_num),
                   'projectName': json.dumps(project_name), 'projectNum': json.dumps(project_num)})


def section(request):
    sec=request.GET.get('section')
    with open('/var/www/learn/static/json/'+str(sec)+'.json','r') as f:
        data=json.load(f)
    dataList=data['time']
    insertList=data['insertions']
    deleteList=data['deletions']
    branchName=data['branchName']
    branchNum=data['branchNum']
    projectName=data['projectName']
    projectNum=data['projectNum']
    return render(request, 'section.html',
                  {'dateList': json.dumps(dataList),
                   'insertList': json.dumps(insertList), 'deleteList': json.dumps(deleteList),
                   'branchName': json.dumps(branchName), 'branchNum': json.dumps(branchNum),
                   'projectName': json.dumps(projectName), 'projectNum': json.dumps(projectNum)})
