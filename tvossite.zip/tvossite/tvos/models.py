import os

from django.db import models

# Create your models here.

class Record(models.Model):
    number=models.IntegerField(primary_key=True)
    project=models.CharField(max_length=50)
    branch=models.CharField(max_length=20)
    updated=models.DateField()
    insertions=models.IntegerField()
    deletions=models.IntegerField()
    owner=models.CharField(max_length=16)
    company=models.CharField(max_length=16)
    section = models.CharField(max_length=10)
    def __str__(self):
        return self.number


class Info(models.Model):
    filepath=models.CharField(max_length=250)
    project=models.CharField(max_length=50)
    insertions=models.IntegerField()
    deletions=models.IntegerField()
    num=models.IntegerField()

    class Meta:
        unique_together = ('filepath', 'project')



    def __str__(self):
        return os.path.join(self.project,self.filepath)
